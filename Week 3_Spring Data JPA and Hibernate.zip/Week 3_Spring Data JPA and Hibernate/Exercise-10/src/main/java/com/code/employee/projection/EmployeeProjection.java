package com.code.employee.projection;

public interface EmployeeProjection {

    String getName();
    String getEmail();
}
